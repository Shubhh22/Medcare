<?php
  $error = "";
  require "db.php";
  
  if (isset($_POST["uname"])) {
    $username = $_POST['uname'];
    $pass = $_POST["psw"];
    $query ="SELECT * from user where email='".$username."' AND password='".$pass."' limit 1";
    $ress = mysqli_query($conn, $query);

    if ($ress) {
      if (mysqli_num_rows($ress)) {
        while($row = $ress -> fetch_assoc()){
          if($row["isAdmin"] == 1){
            header('Location: retreive.php');
          } else {
            header('Location: home.html');
          }
        }
        exit();
      } else {
        $error = "Username and password doesn't match";
      }
    } else {
      $error = "Query failed: " . mysqli_error($conn);
    }

  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website design </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    
    

</head>
<body>
  
  <header class="header">
 

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> medcare. </a>
   

    <nav class="navbar">
        <a href="./home.html">home</a>
        <a href="./login.php">login</a>
        
        <a href="./about.html">about</a>
        <a href="./doctors.html">doctors</a>
        <a href="./login.php">book</a>
   
        
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>


</header>
<br><br><br><br><br>
<h3 class="heading"><span>admin </span>login </h3>
<div class="login">
    <form class="login_form" action="#" method="post">
        <div class="login_wrapper">
          <label for="uname"><b>Username</b></label>
          <input type="text" placeholder="Enter Username" name="uname" required>
      
          <label for="psw"><b>Password</b></label>
          <input type="password" placeholder="Enter Password" name="psw" required>
          <?php if (isset($error)) { echo "<p style='color:white'>".$error."</p>"; } ?>
          <button type="submit">Login</button>
         <br>
        </div>
      
        <div class="container" style="background-color:white">
         
          <span class="psw">Forgot <a href="#">password?</a></span>
          
          
        </div>
        <br>
        <div>
        
    </form>
</div>
</body>
<script src="js/script.js"></script>

</html>