<?php
include "db.php";
session_start();

    $query = "SELECT * FROM bookings ORDER BY date";
    $result = mysqli_query($conn, $query);
    $length = mysqli_num_rows($result);

    if(isset($_GET["filter"])) {
        $query = "SELECT * FROM bookings ORDER BY ".$_GET['filter'];
        $result = mysqli_query($conn, $query);
        $length = mysqli_num_rows($result);
    }

    if(isset($_GET["dc"])) {
        $doctor = $_GET["dc"];
        if($_GET["dc"] == "All doctors"){
            $query = "SELECT * FROM bookings";
        } else {
            $query = "SELECT * FROM bookings WHERE doctors='$doctor'";
        }
        $result = mysqli_query($conn, $query);
        if(!$result) {
            
            echo mysqli_error($conn);
        } else {
            $length = mysqli_num_rows($result);
        }
    }

    if(isset($_POST["search"])){
        $search = $_POST["seatchTXT"];
        $q = "SELECT * FROM bookings WHERE name = '$search' OR email = '$search' OR number = '$search' OR doctors = '$search'";
        $result = mysqli_query($conn, $q);

    }   
    echo mysqli_error($conn);

    //delete

    if(isset($_POST["delete"])){
        $deleteidd = $_POST["deleteid"];
        $deleteQuery = "DELETE FROM bookings WHERE id='$deleteidd'";
        $deleteRun = mysqli_query($conn,$deleteQuery);
        echo mysqli_error($conn);

        $query = "SELECT * FROM bookings ORDER BY date";
        $result = mysqli_query($conn, $query);
        $length = mysqli_num_rows($result);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="./retreve.css">
    <link rel="stylesheet" href="./ret.css">


</head>
<body>
<header class="header">


<a href="#" class="logo"> </a>


<nav class="navbar">
  <a href="#">booking history</a>
  <a href="./addDoctors.php">Add Doctor</a>

  <!-- <a href="./">about</a> -->
  


</nav>
</header>
<br>
    <div class="myContainer">
        <h1>booking History</h1>
        <div class=form-container>
            <form class="form" method="POST">
                <input name="seatchTXT" type="text" placeholder="Search by name, email and doctor">
                <button type-"submit" name="search">search</button>
            </form>
        </div>
        <div class="tableWrapper">
        <table>
        <thead>
            <tr>
                <td><a href="retreive.php?filter=name">name</a></td>
                <td><a href="retreive.php?filter=email">email</a></td>
                <td><a href="retreive.php?filter=number">number</a></td>
                <td><a href="retreive.php?filter=date">date</a></td>
                <td><a href="retreive.php?filter=time">time</a></td>
                <td>
                    <form methos="GET" action="#">
                        <select name="dc" id="doctor" onchange="this.form.submit()">
                            <option hidden>Doctors</option>
                            <?php
                                $query = "SELECT * FROM `doctors` WHERE 1";
                                $res = mysqli_query($conn, $query);
                                while($row = mysqli_fetch_array($res)) {
                                    echo "<option>".$row['name']."</option>";
                                }
                            ?>
                            <option>All doctors</option>
                            <option>
                        </select>
                    </form>
                </td>
                <td>action</td>
            </tr>
        </thead>
        <tbody>
            <?php
            if($length > 0) {
                while($row = mysqli_fetch_array($result)){
                    $idd = $row["id"];
                    echo "<tr>
                        <td>".$row["name"]."</td>
                        <td>".$row["email"]."</td>
                        <td>".$row["number"]."</td>
                        <td>".$row["date"]."</td>
                        <td>".$row["time"]."</td>
                        <td>".$row["doctors"]."</td>
                        <td>
                            <form method='POST'>
                                <input name='deleteid' value='$idd' class='hide'>
                                <button name='delete' >Delete</button>
                            </form>
                            <button onClick=window.location.href='./add.php?appointment-id=$idd'>Add</button>
                        </td>
                    </tr>";
                }
            }
            
            ?>
        </tbody>
    </table>
        </div>
    </div>
</body>
</html>