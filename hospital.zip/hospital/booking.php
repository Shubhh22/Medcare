<?php
require 'db.php';


session_start();
if(isset($_POST["name"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $number = $_POST["number"];
    $date = $_POST["date"];
    $time = $_POST["time"];
    $doctors = $_POST["doctors"];


    $todayDte = date("y-m-d");

    // Convert the selected date and today's date to Unix timestamps
    $selectedTimestamp = strtotime($date);
    $todayTimestamp = strtotime($todayDte);

    // Compare the selected date with today's date
    if ($selectedTimestamp < $todayTimestamp) {
        $_SESSION["message"] =  "you can not select past date";
    } else if ($selectedTimestamp > $todayTimestamp) {
        $nextWeekDte = strtotime(date("Y-m-d", strtotime("+1 week")));
        if($nextWeekDte < $selectedTimestamp){
            $_SESSION["message"] = "Please select date within 1 week";
        } else {

            $query = "INSERT INTO bookings (`name`, `number`, `email`, `date`, `time`, `doctors`) VALUES ('$name','$number','$email','$date','$time','$doctors')";
  
            if (mysqli_query($conn, $query)) {
                $_SESSION["message"] = "your appointment has successfully booked!!";
            } else {
                $_SESSION["message"] = "failed to book your appointment";
            }
        }
           
    } else {
        $_SESSION["message"] = "Todays appointment is full" ;
    }





}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hospital apoointment booking</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <?php include("./NavBar.html") ?>
    <!-- <header class="header">

        <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> medcare. </a>  
        <nav class="navbar">
            <a href="./booking.html">book</a>
            <a href="./retreive.php">booking history</a>
           
            <a href="./fitness.html">fitness tips</a>
            <a href="./doctors.html">doctors</a>
           
        </nav>
      
        <div id="menu-btn" class="fas fa-bars"></div>
    
    </header> -->
    
    
    

</head>
<body>
    
    <section class="book" id="book">
    <br>
        <br>
        <br>
        <br>
        <br>

        <h1 class="heading"> <span>book</span> now </h1>    
    
        <div class="row">
    
            <div class="image">
                <img src="image/book-img.svg" alt="">
            </div>
    
            <form action="#" method="post">
                <h3>book appointment</h3>
                <input name="name" type="text" required placeholder="your name" class="box">
                <input name="number"  type="tel" id="phone" name="phone" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" required required placeholder="your contact number" class="box">
                <input name="email" type="email" required placeholder="your email" class="box">
                <input name="date" type="date" required placeholder="enter date" class="box">
                <input name="time" type="time"  required placeholder="time" class="box">
                <select name="doctors" required placeholder="select doctor"class="box">
                    <?php
                        $query = "SELECT * FROM `doctors` WHERE 1";
                        $res = mysqli_query($conn, $query);
                        while($row = mysqli_fetch_array($res)) {
                            echo "<option>".$row['name']."</option>";
                        }
                    ?>
                </select>
               
                <?php if (isset($_SESSION["message"])) { echo "<h1>".$_SESSION["message"]."</h1>"; } unset($_SESSION["message"])?>

                <input type="submit" value="book now" class="btn">
            </form>
    
        </div>
    
    </section>
    <script src="js/script.js"></script>
</body>
</html>