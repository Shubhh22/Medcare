<?php
include 'db.php';

if (isset($_POST["name"])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = $_POST['psw'];
 

  $query = "INSERT INTO user (`name`, `email`, `password`) VALUES ('$name','$email','$pass')";

    if (mysqli_query($conn, $query)) {
        header('Location: login.php');
        exit();
    } else {
        $error = "Failed to register: " . mysqli_error($conn);
    }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    <form action="#" method="POST" style="border:1px solid #ccc">
        <div class="container">
          <h1>Sign Up</h1>
          <p>Please fill in this form to create an account.</p>
          <hr>
      
          <label for="email"><b>Email</b></label>
          <input type="email" placeholder="Enter Email" name="email" required>
      
          <label for="psw"><b>Password</b></label>
          <input type="password" placeholder="Enter Password" name="psw" required>
      
          <label for="psw-repeat"><b>full name</b></label>
          <input type="text" placeholder="full name" name="name" required>
      
         
      
          <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
      
          <div class="clearfix">
            <button type="button" class="cancelbtn">Cancel</button>
            <button type="submit" class="signupbtn">Sign Up</button>
          </div>
        </div>
      </form>
</body>
</html>