<?php
    require "./db.php";

    if(isset($_GET["appointment-id"])){
        $bookingId = $_GET["appointment-id"];
        $query = "SELECT * FROM `bookings` WHERE id=$bookingId";
    
        $res = mysqli_query($conn, $query);
        $resL = mysqli_num_rows($res);
    
        $user =null;
        while($row = mysqli_fetch_array($res)){
            $user = $row["email"];
        }
    }

    if (isset($_POST["medicine"])) {
        $medicine = $_POST['medicine'];
        $diets = $_POST['diets'];
        $revisit = $_POST['revisit'];
        $query = "INSERT INTO prescription (`apoi_id`, `medicine`, `diets`, `user`,`revisit`) VALUES ('$bookingId','$medicine','$diets','$user','$revisit')";
      
        if (mysqli_query($conn, $query)) {
            $error = "prescription added successfully";
        } else {
            $error = "failed to add prescription";  
        }
    }
    echo mysqli_error($conn)
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="add.css">
    <link rel="stylesheet" href="ret.css">
</head>

<body>
<header class="header">


<a href="#" class="logo"> </a>


<nav class="navbar">
  <a href="./retreive.php">booking history</a>
  <a href="./addDoctors.php">Add Doctor</a>

  <!-- <a href="./">about</a> -->
  


</nav>
</header>
    <div class="add_container">
        <form method="POST" action="#">
            <h2>Prescription Details</h2>
            <div class="form-group">
                <label for="appointment-id">Appointment ID:</label>
                <input value=<?php echo $bookingId?> readonly="true" type="text" id="appointment-id" name="appointment-id">
            </div>
            <div class="form-group">
                <label for="medicine">Prescription:</label>
                <input type="text" id="medicine" name="medicine">
            </div>
            <div class="form-group">
                <label for="diets">Diets:</label>
                <input type="text" id="diets" name="diets">
            </div>
            <div class="form-group">
                <label for="revisit">follow up</label>
                <input type="date" id="revisit" name="revisit">
            </div>
            <div class="form-group">
                <label for="user-id">User ID:</label>
                <input value=<?php echo $user?> readonly="true" type="text" id="user-id" name="user-id">
            </div>
            <?php if (isset($error)) {echo "<h3>$error</h3>";} ?>
            <button type="submit" class="btn">Submit</button>
        </form>

    </div>
</body>

</html>