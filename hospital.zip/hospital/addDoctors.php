<?php
    require "./db.php";

    if (isset($_POST["experties"])) {
        $experties = $_POST['experties'];
        $name = $_POST['name'];
        $from = $_POST['from'];
        $too = $_POST['too'];
        $fees = $_POST['fees'];
        $query = "INSERT INTO `doctors`(`name`, `experties`, `from`, `to`, `fees`) VALUES ('$name','$experties','$from','$too','$fees')";
      
        if (mysqli_query($conn, $query)) {
            $error = "Doctor added successfully";
        } else {
            $error = "failed to add Doctor";  
        }
    }
    echo mysqli_error($conn)
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="add.css">
    <link rel="stylesheet" href="ret.css">
</head>

<body>
<header class="header">


<a href="#" class="logo"> </a>


<nav class="navbar">
  <a href="./retreive.php">booking history</a>
  <a href="#">Add Doctor</a>

  <!-- <a href="./">about</a> -->
  


</nav>
</header>
    
    <div class="add_container">
        <form method="POST" action="#">
            <h2>Add Doctor</h2>
            <div class="form-group">
                <label for="name">name:</label>
                <input type="text" id="name" name="name">
            </div>
            <div class="form-group">
                <label for="experties">experties:</label>
                <input type="text" id="experties" name="experties">
            </div>
            <div class="form-group">
                <label for="from">from:</label>
                <input type="time" id="from" name="from">
            </div>
            <div class="form-group">
                <label for="too">too</label>
                <input type="time" id="too" name="too">
            </div>
            <div class="form-group">
                <label for="fees">fees:</label>
                <input type="text" id="fees" name="fees">
            </div>
            <?php if (isset($error)) {echo "<h3>$error</h3>";} ?>
            <button type="submit" class="btn">Submit</button>
        </form>

    </div>
</body>

</html>