<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./retreve.css">
</head>
<body>
    <table>
        <thead>
            <tr>
                <td><a href="retreive.php?filter=name">apoinment id</a></td>
                <td><a href="retreive.php?filter=email">prescriptions</a></td>
                <td><a href="retreive.php?filter=number">diet</a></td>
                <td><a href="retreive.php?filter=date">follow up</a></td>
            </tr>
        </thead>
        <tbody>
            <?php
            include('./db.php');
            session_start();
            $email = $_SESSION["email"];
            $q = "SELECT * FROM `prescription` WHERE USER='$email'";
            $result = mysqli_query($conn, $q);
            $length = mysqli_num_rows($result);
            if($length > 0) {
                while($row = mysqli_fetch_array($result)){
                    $idd = $row["id"];
                    echo "<tr>
                        <td>".$row["apoi_id"]."</td>
                        <td>".$row["medicine"]."</td>
                        <td>".$row["diets"]."</td>
                        <td>Revisit</td>
                    </tr>";
                }
            }
            
            ?>
        </tbody>
    </table>
</body>
</html>